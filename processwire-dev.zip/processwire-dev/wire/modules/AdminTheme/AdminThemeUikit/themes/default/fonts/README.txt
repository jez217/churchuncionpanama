Source of Inter fonts: 
https://github.com/rsms/inter