<?php namespace ProcessWire;

return [
	'title' => 'Konkat default',
	'author' => 'Konkat Studio',
];
