This is a placeholder file that can be deleted 
once there is a theme directory within this. 